'use client';

import { GlassCard } from '@/components/glass-card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

export function FaqSection() {
  const faqs = [
    {
      question: "How much does your consultation cost?",
      answer:
        "Our initial consultation is completely free. There are no hidden charges or obligations. You get expert advice with zero financial risk.",
    },
    {
      question: "Will switching damage my credit?",
      answer:
        "No. Switching internet or cable providers does not affect your credit score. It's a simple service change, not a credit inquiry.",
    },
    {
      question: "What if I'm locked in a contract?",
      answer:
        "Many contracts have buyout options or windows to switch without penalties. We'll analyze your specific situation and find the best path forward.",
    },
    {
      question: "Do you work with all providers?",
      answer:
        "We have partnerships with most major and regional providers. Even if your preferred provider isn't listed, we can still help you compare options.",
    },
    {
      question: "How long does switching usually take?",
      answer:
        "Most customers complete the entire process—from consultation to new service activation—in 7-10 business days. No downtime required.",
    },
    {
      question: "What if I'm not satisfied with my new plan?",
      answer:
        "We stand behind our recommendations. If you're unhappy within 30 days, we'll help you explore other options at no additional cost.",
    },
  ];

  return (
    <section className="py-20 bg-card/10 backdrop-blur-sm border-y border-border/20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-4 slide-up">
          <h2 className="text-4xl lg:text-5xl font-bold">
            <span className="text-foreground">Questions?—</span>
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">We've Got Answers</span>
          </h2>
          <p className="text-lg text-foreground/60">
            Everything you need to know about our service and process.
          </p>
        </div>

        <GlassCard className="p-8" glow="blue">
          <Accordion type="single" collapsible className="w-full space-y-2">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-border/20">
                <AccordionTrigger className="hover:text-accent transition-colors py-4 text-left">
                  <span className="font-semibold text-foreground">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="text-foreground/70 pb-4 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </GlassCard>

        <GlassCard className="p-8 text-center" glow="purple">
          <div className="space-y-4">
            <p className="text-lg font-semibold text-foreground">Didn't find your answer?</p>
            <p className="text-foreground/60 mb-4">
              Our team is ready to help. Call for a quick answer.
            </p>
            <button className="px-6 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-colors">
              Call Us Now
            </button>
          </div>
        </GlassCard>
      </div>
    </section>
  );
}
