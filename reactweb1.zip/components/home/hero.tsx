'use client';

import { PhoneCta } from '@/components/phone-cta';
import { GlassCard } from '@/components/glass-card';
import Image from 'next/image';
import { Zap, Wifi, TrendingDown, Clock, CheckCircle2 } from 'lucide-react';

export function HeroSection() {
  return (
    <div>
      {/* Modern Asymmetrical Bento Hero */}
      <section className="relative min-h-screen bg-gradient-to-br from-background via-background to-card/20 overflow-hidden pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Main Grid - Asymmetrical Bento Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Left Column - Large Text + CTA */}
            <div className="lg:col-span-1 flex flex-col justify-between lg:row-span-2">
              <div className="space-y-6 mb-8">
                <div className="space-y-3">
                  <h1 className="text-5xl lg:text-6xl font-bold leading-tight text-balance">
                    <span className="text-foreground">Cut Your </span>
                    <span className="bg-gradient-to-r from-accent to-secondary bg-clip-text text-transparent">Cable Bills</span>
                    <span className="text-foreground"> in Half</span>
                  </h1>
                  <p className="text-lg text-foreground/70 leading-relaxed">
                    Expert guidance on finding better plans. Independent. Transparent. Zero commissions.
                  </p>
                </div>

                <div className="space-y-2 pt-4">
                  <div className="flex gap-2 items-center">
                    <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                    <span className="text-sm text-foreground/80">Free expert consultation</span>
                  </div>
                  <div className="flex gap-2 items-center">
                    <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                    <span className="text-sm text-foreground/80">No hidden fees or obligations</span>
                  </div>
                  <div className="flex gap-2 items-center">
                    <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                    <span className="text-sm text-foreground/80">Save $40-80+ per month</span>
                  </div>
                </div>
              </div>

              <PhoneCta size="lg" label="Get Free Consultation" subtitle="Talk to an expert today" />
            </div>

            {/* Right Column - Image Card Large */}
            <div className="lg:col-span-2 lg:row-span-2 relative rounded-2xl overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-secondary/10 group-hover:from-accent/30 group-hover:to-secondary/20 transition-all duration-500 z-10" />
              <Image
                src="/images/router.jpg"
                alt="Modern WiFi Router"
                width={600}
                height={600}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-20" />
            </div>
          </div>

          {/* Secondary Grid - Stats & Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Stat Card 1 */}
            <GlassCard className="p-6 flex flex-col items-center text-center glow-blue" glow="blue">
              <div className="mb-4 p-3 bg-accent/10 rounded-lg">
                <TrendingDown className="w-6 h-6 text-accent" />
              </div>
              <p className="text-5xl font-bold text-accent mb-2">$58</p>
              <p className="text-foreground/70 text-sm">Average monthly savings</p>
            </GlassCard>

            {/* Stat Card 2 */}
            <GlassCard className="p-6 flex flex-col items-center text-center glow-purple" glow="purple">
              <div className="mb-4 p-3 bg-secondary/10 rounded-lg">
                <Wifi className="w-6 h-6 text-secondary" />
              </div>
              <p className="text-5xl font-bold text-secondary mb-2">12K+</p>
              <p className="text-foreground/70 text-sm">Customers helped since 2020</p>
            </GlassCard>

            {/* Stat Card 3 */}
            <GlassCard className="p-6 flex flex-col items-center text-center glow-blue" glow="blue">
              <div className="mb-4 p-3 bg-accent/10 rounded-lg">
                <Clock className="w-6 h-6 text-accent" />
              </div>
              <p className="text-5xl font-bold text-accent mb-2">10min</p>
              <p className="text-foreground/70 text-sm">Free expert consultation</p>
            </GlassCard>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-20 right-10 w-40 h-40 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-10 w-60 h-60 bg-secondary/5 rounded-full blur-3xl" />
      </section>

      {/* Feature Strip - Bento Style */}
      <section className="relative py-16 bg-card/30 border-y border-border/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Zap, label: 'Fastest Switching', desc: '7-10 days' },
              { icon: CheckCircle2, label: 'Zero Downtime', desc: 'Seamless transition' },
              { icon: Wifi, label: 'Better Speeds', desc: 'Lower prices' },
              { icon: TrendingDown, label: 'No Hidden Fees', desc: 'Total transparency' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <GlassCard key={i} className="p-4 flex items-center gap-3 glow-blue" glow={i % 2 === 0 ? 'blue' : 'purple'}>
                  <Icon className="w-5 h-5 text-accent flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-foreground text-sm">{item.label}</p>
                    <p className="text-xs text-foreground/60">{item.desc}</p>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        </div>
      </section>

      {/* Content Showcase Section */}
      <section className="relative py-20 bg-gradient-to-b from-background to-card/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">
            <span className="text-foreground">Why Customers </span>
            <span className="bg-gradient-to-r from-accent to-secondary bg-clip-text text-transparent">Trust Us</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Featured Large Card */}
            <div className="lg:col-span-2 lg:row-span-1 rounded-2xl overflow-hidden group relative h-80">
              <Image
                src="/images/fiber-optic.jpg"
                alt="Fiber Optic Connection"
                width={800}
                height={300}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent flex items-end p-6 z-10">
                <div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">Lightning-Fast Speeds</h3>
                  <p className="text-foreground/70">Get the fastest internet available in your area</p>
                </div>
              </div>
            </div>

            {/* Text Cards Grid */}
            <GlassCard className="p-6 flex flex-col justify-between glow-blue" glow="blue">
              <div>
                <h3 className="font-semibold text-foreground mb-2">100% Independent</h3>
                <p className="text-sm text-foreground/70">No commissions. No affiliate bias. Just honest advice for you.</p>
              </div>
            </GlassCard>

            <GlassCard className="p-6 flex flex-col justify-between glow-purple" glow="purple">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Expert Team</h3>
                <p className="text-sm text-foreground/70">Industry veterans who know every provider inside and out.</p>
              </div>
            </GlassCard>

            <GlassCard className="p-6 flex flex-col justify-between glow-blue" glow="blue">
              <div>
                <h3 className="font-semibold text-foreground mb-2">24/7 Support</h3>
                <p className="text-sm text-foreground/70">We're here before, during, and after your switch.</p>
              </div>
            </GlassCard>
          </div>
        </div>
      </section>
    </div>
  );
}
