'use client';

import { GlassCard } from '@/components/glass-card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Phone } from 'lucide-react';

export function FinalCtaSection() {
  return (
    <section className="py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <GlassCard
          className="p-12 md:p-16 text-center space-y-8 bg-gradient-to-br from-primary/15 to-accent/15 border-primary/30 glow-blue"
          glow="blue"
        >
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold leading-tight">
              <span className="text-foreground">Ready to </span>
              <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Stop Overpaying?</span>
            </h2>
            <p className="text-lg text-foreground/70">
              Join thousands who've already switched to better plans. Your free consultation starts right now.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold gap-2 h-12 px-6 text-base sm:text-lg">
              <Phone className="w-5 h-5" />
              Call for Free Consultation
              <ArrowRight className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              className="border-foreground/20 hover:bg-foreground/5 font-semibold h-12 px-6 text-base sm:text-lg"
            >
              Learn More
            </Button>
          </div>

          <div className="flex flex-col sm:flex-row justify-center gap-6 text-sm text-foreground/60 pt-4 border-t border-border/30">
            <div className="flex gap-2 items-center justify-center">
              <span className="text-accent">✓</span>
              <span>No obligation</span>
            </div>
            <div className="flex gap-2 items-center justify-center">
              <span className="text-accent">✓</span>
              <span>Only 10 minutes</span>
            </div>
            <div className="flex gap-2 items-center justify-center">
              <span className="text-accent">✓</span>
              <span>Immediate savings plan</span>
            </div>
          </div>
        </GlassCard>
      </div>
    </section>
  );
}
