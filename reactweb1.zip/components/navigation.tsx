'use client';

import Link from 'next/link';
import { Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Navigation() {
  return (
    <nav className="sticky top-0 z-50 glass border-b border-border/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="text-xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
            CableGuide
          </Link>

          <div className="hidden md:flex gap-8">
            <Link href="/" className="text-sm text-foreground/70 hover:text-foreground transition-colors">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm text-foreground/70 hover:text-foreground transition-colors">
              How It Works
            </Link>
            <Link href="/services" className="text-sm text-foreground/70 hover:text-foreground transition-colors">
              Services
            </Link>
            <Link href="/faq" className="text-sm text-foreground/70 hover:text-foreground transition-colors">
              FAQ
            </Link>
            <Link href="/contact" className="text-sm text-foreground/70 hover:text-foreground transition-colors">
              Contact
            </Link>
          </div>

          <Button
            className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2"
            size="sm"
          >
            <Phone className="w-4 h-4" />
            Call Now
          </Button>
        </div>
      </div>
    </nav>
  );
}
