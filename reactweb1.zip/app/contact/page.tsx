import { GlassCard } from '@/components/glass-card';
import { Phone, Mail, MessageSquare } from 'lucide-react';

export const metadata = {
  title: 'Contact Us - CableGuide',
  description: 'Get in touch with our cable and internet specialists. Free consultation available.',
};

export default function ContactPage() {
  return (
    <main>
      <section className="py-20 bg-card/10 backdrop-blur-sm border-b border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h1 className="text-5xl lg:text-6xl font-bold">
            <span className="text-foreground">Get In Touch—</span>
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">We're Here to Help</span>
          </h1>
          <p className="text-xl text-foreground/70">
            Our team is ready to answer your questions and start your free consultation.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            <GlassCard className="p-8 text-center" glow="blue">
              <Phone className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">Call Us</h3>
              <p className="text-foreground/70 mb-4">
                Speak directly with our specialists. No wait, no automated systems.
              </p>
              <p className="text-2xl font-bold text-accent mb-2">1-800-CABLE-GUIDE</p>
              <p className="text-sm text-foreground/60">
                Available Monday-Friday, 9am-8pm EST
              </p>
            </GlassCard>

            <GlassCard className="p-8 text-center" glow="purple">
              <Mail className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">Email Us</h3>
              <p className="text-foreground/70 mb-4">
                Prefer to reach out by email? We'll respond within 24 hours.
              </p>
              <p className="text-lg font-semibold text-accent mb-2">hello@cableguide.com</p>
              <p className="text-sm text-foreground/60">
                We answer every message personally
              </p>
            </GlassCard>

            <GlassCard className="p-8 text-center" glow="blue">
              <MessageSquare className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">Live Chat</h3>
              <p className="text-foreground/70 mb-4">
                Quick questions? Chat with our team right now.
              </p>
              <button className="px-6 py-2 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-colors">
                Start Chat
              </button>
            </GlassCard>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <GlassCard className="p-8" glow="blue">
              <h3 className="text-2xl font-bold text-foreground mb-6">Ready for Your Free Consultation?</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Your Name</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-input border border-border rounded-lg text-foreground placeholder:text-foreground/40 focus:outline-none focus:ring-2 focus:ring-accent"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Phone Number</label>
                  <input
                    type="tel"
                    className="w-full px-4 py-2 bg-input border border-border rounded-lg text-foreground placeholder:text-foreground/40 focus:outline-none focus:ring-2 focus:ring-accent"
                    placeholder="(555) 123-4567"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Current Provider</label>
                  <select className="w-full px-4 py-2 bg-input border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent">
                    <option>Select a provider...</option>
                    <option>Comcast</option>
                    <option>Charter</option>
                    <option>Verizon</option>
                    <option>AT&T</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Monthly Bill</label>
                  <input
                    type="number"
                    className="w-full px-4 py-2 bg-input border border-border rounded-lg text-foreground placeholder:text-foreground/40 focus:outline-none focus:ring-2 focus:ring-accent"
                    placeholder="$150"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-colors"
                >
                  Schedule Consultation
                </button>
              </form>
            </GlassCard>

            <GlassCard className="p-8" glow="purple">
              <h3 className="text-2xl font-bold text-foreground mb-6">What to Expect</h3>
              <ul className="space-y-4">
                <li className="flex gap-4">
                  <span className="text-accent font-bold">1</span>
                  <div>
                    <p className="font-semibold text-foreground">Initial Call (5-10 min)</p>
                    <p className="text-sm text-foreground/60">
                      We ask about your current service and needs
                    </p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className="text-accent font-bold">2</span>
                  <div>
                    <p className="font-semibold text-foreground">Analysis (24 hours)</p>
                    <p className="text-sm text-foreground/60">
                      We research and compare available options
                    </p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className="text-accent font-bold">3</span>
                  <div>
                    <p className="font-semibold text-foreground">Follow-up Consultation</p>
                    <p className="text-sm text-foreground/60">
                      We present options and answer all questions
                    </p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className="text-accent font-bold">4</span>
                  <div>
                    <p className="font-semibold text-foreground">Switch (7-10 business days)</p>
                    <p className="text-sm text-foreground/60">
                      We guide you through the activation process
                    </p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className="text-accent font-bold">5</span>
                  <div>
                    <p className="font-semibold text-foreground">Start Saving</p>
                    <p className="text-sm text-foreground/60">
                      Enjoy lower bills starting your first month
                    </p>
                  </div>
                </li>
              </ul>
            </GlassCard>
          </div>
        </div>
      </section>

      <section className="py-20 bg-card/10 backdrop-blur-sm border-t border-border/20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-3xl font-bold text-foreground">Ready to Get Started?</h2>
          <p className="text-lg text-foreground/70">
            Your free consultation is just a phone call away.
          </p>
          <button className="inline-block px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-colors">
            Call Now: 1-800-CABLE-GUIDE
          </button>
        </div>
      </section>
    </main>
  );
}
