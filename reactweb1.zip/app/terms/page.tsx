import { GlassCard } from '@/components/glass-card';

export const metadata = {
  title: 'Terms of Service - CableGuide',
  description: 'Our terms of service and user agreement.',
};

export default function TermsPage() {
  return (
    <main>
      <section className="py-20 bg-card/10 backdrop-blur-sm border-b border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-foreground mb-6">Terms of Service</h1>
          <p className="text-lg text-foreground/70">
            Last updated: February 2024
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">1. Acceptance of Terms</h2>
            <p className="text-foreground/70 leading-relaxed">
              By using CableGuide services, you agree to these terms and conditions. If you do not agree, please do not use our services.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">2. Service Description</h2>
            <p className="text-foreground/70 leading-relaxed">
              CableGuide provides independent guidance on cable and internet plans. Our consultations are informational only and not a guarantee of savings or service quality from any provider. Actual results depend on your location, current plan, and service availability.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">3. No Affiliation</h2>
            <p className="text-foreground/70 leading-relaxed">
              CableGuide is independent and not affiliated with any internet service provider, cable company, or telecommunications provider. We do not sell services or represent any specific provider.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">4. Limitations of Liability</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              While we strive to provide accurate information, we do not guarantee the accuracy, completeness, or timeliness of all information. We are not liable for any indirect, incidental, or consequential damages resulting from your use of our services or reliance on our recommendations.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">5. User Responsibilities</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              You are responsible for providing accurate information during consultations. You agree to verify all terms and conditions with ISPs directly before signing any contracts or committing to switching services.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">6. Limitation Period</h2>
            <p className="text-foreground/70 leading-relaxed">
              Any claim against CableGuide must be brought within one year of the action or omission giving rise to the claim.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">7. Changes to Terms</h2>
            <p className="text-foreground/70 leading-relaxed">
              We may update these terms at any time. Continued use of our services indicates your acceptance of changes.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">8. Contact</h2>
            <p className="text-foreground/70 leading-relaxed">
              For questions about these terms, contact us at legal@cableguide.com or call 1-800-CABLE-GUIDE.
            </p>
          </GlassCard>
        </div>
      </section>
    </main>
  );
}
