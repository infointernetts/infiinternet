import { GlassCard } from '@/components/glass-card';
import { TrendingDown, Zap, BarChart3, Shield } from 'lucide-react';

export const metadata = {
  title: 'Services - CableGuide',
  description: 'Discover our cable and internet guidance services. Plan analysis, comparison, and switching support.',
};

export default function ServicesPage() {
  const services = [
    {
      icon: BarChart3,
      title: 'Plan Analysis',
      description:
        'We break down your current plan and identify where you might be overpaying. No jargon, just clear comparisons.',
      details: [
        'Current plan evaluation',
        'Speed requirement analysis',
        'Identifying overage charges',
        'Hidden fee detection',
      ],
    },
    {
      icon: TrendingDown,
      title: 'Savings Comparison',
      description:
        'Compare plans side-by-side with real cost calculations over 12-24 months. See your actual savings potential.',
      details: [
        'Multi-provider comparison',
        'True cost-of-ownership calculation',
        'Contract term analysis',
        'Promotional rate transparency',
      ],
    },
    {
      icon: Zap,
      title: 'Speed Optimization',
      description:
        'Not all speeds are necessary for everyone. We find the right speed that matches your needs—not ISP marketing.',
      details: [
        'Usage pattern assessment',
        'Speed requirement calculation',
        'Performance testing recommendations',
        'Future-proofing advice',
      ],
    },
    {
      icon: Shield,
      title: 'Switch Support',
      description:
        'We guide you through the entire switching process. Get answers to every question without ISP sales tactics.',
      details: [
        'Contract buyout guidance',
        'Early termination fee analysis',
        'Setup and activation support',
        'Post-switch troubleshooting',
      ],
    },
  ];

  return (
    <main>
      <section className="py-20 bg-card/10 backdrop-blur-sm border-b border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h1 className="text-5xl lg:text-6xl font-bold">
            <span className="text-foreground">Our Services—</span>
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Complete Solutions</span>
          </h1>
          <p className="text-xl text-foreground/70">
            From analysis to activation, we handle every step of your cable and internet upgrade.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <GlassCard
                  key={index}
                  className="p-8 flex flex-col space-y-6"
                  glow={index % 2 === 0 ? 'blue' : 'purple'}
                >
                  <Icon className="w-12 h-12 text-accent" />
                  <div className="space-y-2 flex-1">
                    <h3 className="text-2xl font-semibold text-foreground">{service.title}</h3>
                    <p className="text-foreground/70 leading-relaxed">{service.description}</p>
                  </div>
                  <ul className="space-y-3 border-t border-border/40 pt-6">
                    {service.details.map((detail, i) => (
                      <li key={i} className="flex gap-3 text-sm">
                        <span className="text-accent flex-shrink-0">✓</span>
                        <span className="text-foreground/80">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </GlassCard>
              );
            })}
          </div>

          <GlassCard className="p-12 text-center space-y-6 bg-gradient-to-r from-accent/10 to-primary/10 glow-blue">
            <h3 className="text-3xl font-bold text-foreground">
              All Services Are <span className="text-accent">100% Free</span>
            </h3>
            <p className="text-lg text-foreground/70 leading-relaxed">
              We don't charge for consultations, analysis, or guidance. We make money when you save money—and not before. Your satisfaction is our only priority.
            </p>
          </GlassCard>
        </div>
      </section>

      <section className="py-20 bg-card/10 backdrop-blur-sm border-t border-border/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="space-y-3">
              <p className="text-4xl font-bold text-accent">$58</p>
              <p className="text-foreground/70">Average Monthly Savings</p>
              <p className="text-sm text-foreground/50">From our customers</p>
            </div>
            <div className="space-y-3">
              <p className="text-4xl font-bold text-primary">30min</p>
              <p className="text-foreground/70">Average Consultation</p>
              <p className="text-sm text-foreground/50">To get started</p>
            </div>
            <div className="space-y-3">
              <p className="text-4xl font-bold text-accent">4.9★</p>
              <p className="text-foreground/70">Customer Rating</p>
              <p className="text-sm text-foreground/50">Across all services</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-b from-transparent to-card/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Why Customers Choose Us</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <GlassCard className="p-8" glow="blue">
              <h3 className="font-semibold text-foreground text-lg mb-3">Completely Independent</h3>
              <p className="text-foreground/70">
                We have no financial ties to any ISP. No commissions, no affiliate bonuses. Our only incentive is to find you the best deal possible.
              </p>
            </GlassCard>

            <GlassCard className="p-8" glow="purple">
              <h3 className="font-semibold text-foreground text-lg mb-3">Transparent Pricing</h3>
              <p className="text-foreground/70">
                We show you every cost—setup fees, equipment charges, promotional rates, and what you'll pay when promotions end. No surprises.
              </p>
            </GlassCard>

            <GlassCard className="p-8" glow="blue">
              <h3 className="font-semibold text-foreground text-lg mb-3">Expert Knowledge</h3>
              <p className="text-foreground/70">
                Our team stays current on every provider's offerings, new technology, and pricing changes. You get insights that ISP sales reps won't share.
              </p>
            </GlassCard>

            <GlassCard className="p-8" glow="purple">
              <h3 className="font-semibold text-foreground text-lg mb-3">Ongoing Support</h3>
              <p className="text-foreground/70">
                Switching is just the beginning. We're here to help with setup, troubleshooting, and making sure you're genuinely satisfied.
              </p>
            </GlassCard>
          </div>
        </div>
      </section>

      <section className="py-20 bg-card/10 backdrop-blur-sm border-t border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="text-foreground">Our Unique </span>
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Process</span>
          </h2>

          <div className="space-y-4">
            {[
              {
                step: "1",
                title: "Listen",
                description: "We ask detailed questions about your current service, speeds, usage, and budget. We're here to understand, not to sell."
              },
              {
                step: "2", 
                title: "Analyze",
                description: "We research all available options in your area, calculate true costs, and identify where you're overpaying."
              },
              {
                step: "3",
                title: "Recommend",
                description: "We present options ranked by actual savings and quality. You make the decision with full information."
              },
              {
                step: "4",
                title: "Execute",
                description: "We handle the switching process. Your service continues uninterrupted until you're connected to your new plan."
              },
              {
                step: "5",
                title: "Support",
                description: "Setup issues? Questions about your new plan? We're here to help you succeed with your choice."
              }
            ].map((item, index) => (
              <GlassCard key={index} className="p-6 flex gap-6 items-start" glow={index % 2 === 0 ? 'blue' : 'purple'}>
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                  <span className="font-bold text-accent">{item.step}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground text-lg">{item.title}</h3>
                  <p className="text-foreground/70 mt-2">{item.description}</p>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-3xl font-bold text-foreground">Experience Our Service Firsthand</h2>
          <p className="text-lg text-foreground/70">
            Get a free consultation and see why thousands of customers trust us with their switching needs.
          </p>
          <button className="inline-block px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-colors">
            Call for Free Consultation
          </button>
        </div>
      </section>
    </main>
  );
}
