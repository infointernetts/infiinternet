import { GlassCard } from '@/components/glass-card';
import { AlertCircle } from 'lucide-react';

export const metadata = {
  title: 'Disclaimer - CableGuide',
  description: 'Important disclaimer about our services and recommendations.',
};

export default function DisclaimerPage() {
  return (
    <main>
      <section className="py-20 bg-card/10 backdrop-blur-sm border-b border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-foreground mb-6">Disclaimer</h1>
          <p className="text-lg text-foreground/70">
            Last updated: February 2024
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <GlassCard className="p-8 bg-destructive/5 border-destructive/20 glow-blue" glow="none">
            <div className="flex gap-4">
              <AlertCircle className="w-8 h-8 text-destructive flex-shrink-0 mt-1" />
              <div>
                <h2 className="text-xl font-bold text-foreground mb-2">Important Notice</h2>
                <p className="text-foreground/70 leading-relaxed">
                  CableGuide provides general informational guidance only. We are an independent third party and not affiliated with any internet service provider or telecommunications company. Our recommendations are based on publicly available information and general industry knowledge.
                </p>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">No Warranty or Guarantee</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              CableGuide makes no warranties, express or implied, regarding the accuracy, completeness, or reliability of information provided. We do not guarantee:
            </p>
            <ul className="space-y-2 text-foreground/70">
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Specific savings amounts or percentages</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Service quality from any provider</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Availability of plans in your specific area</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Speed performance or reliability</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Absence of service interruptions</span>
              </li>
            </ul>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">Provider Terms and Conditions</h2>
            <p className="text-foreground/70 leading-relaxed">
              All internet service providers have their own terms, conditions, and policies. You are responsible for reading and understanding these directly before committing to any service. Early termination fees, contract terms, and service limitations are the responsibility of the provider and are outside CableGuide's control.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">Changing Provider Information</h2>
            <p className="text-foreground/70 leading-relaxed">
              Internet service providers frequently change their plans, pricing, and service offerings. While we strive to provide current information, pricing and plan availability can change at any time. We recommend verifying current offerings directly with providers.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">Your Responsibility</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              You are responsible for:
            </p>
            <ul className="space-y-2 text-foreground/70">
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Verifying all information with providers directly</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Understanding contract terms before signing</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Reviewing all promotional terms and conditions</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>Checking what rates apply after promotional periods</span>
              </li>
            </ul>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">No Professional Advice</h2>
            <p className="text-foreground/70 leading-relaxed">
              CableGuide consultations are for informational purposes only and do not constitute legal, financial, or professional advice. We recommend consulting with appropriate professionals for personalized guidance specific to your situation.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">Independent Service</h2>
            <p className="text-foreground/70 leading-relaxed">
              CableGuide is an independent service not endorsed, affiliated with, or representing any internet service provider. Our recommendations are based on general knowledge and available options in your area, not proprietary provider information.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">Limitation of Liability</h2>
            <p className="text-foreground/70 leading-relaxed">
              To the maximum extent permitted by law, CableGuide is not liable for any damages resulting from use of our services, reliance on recommendations, or switching to any provider. This includes direct, indirect, incidental, or consequential damages.
            </p>
          </GlassCard>

          <GlassCard className="p-8 bg-card/50" glow="none">
            <p className="text-sm text-foreground/60 leading-relaxed">
              By using CableGuide services, you acknowledge that you have read and understand this disclaimer and agree to its terms.
            </p>
          </GlassCard>
        </div>
      </section>
    </main>
  );
}
