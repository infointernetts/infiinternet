import { GlassCard } from '@/components/glass-card';
import { CheckCircle } from 'lucide-react';

export const metadata = {
  title: 'Refund Policy - CableGuide',
  description: 'Our refund and satisfaction policy.',
};

export default function RefundPage() {
  return (
    <main>
      <section className="py-20 bg-card/10 backdrop-blur-sm border-b border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-foreground mb-6">Refund & Satisfaction Policy</h1>
          <p className="text-lg text-foreground/70">
            Our commitment to your satisfaction
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">Free Consultation Guarantee</h2>
            <p className="text-foreground/70 leading-relaxed">
              Our consultation services are completely free. You will never be charged for our initial assessment, analysis, or recommendations. If you choose not to switch providers, you owe us nothing.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">30-Day Satisfaction Guarantee</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              After switching to a provider we recommended, if you are not satisfied within the first 30 days, we will:
            </p>
            <ul className="space-y-3">
              <li className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground/70">Review your concerns without judgment</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground/70">Help you explore alternative options</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground/70">Support switching to another provider if needed</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground/70">Provide this additional support at no charge</span>
              </li>
            </ul>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">What This Does NOT Cover</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              Our satisfaction guarantee does not cover:
            </p>
            <ul className="space-y-2 text-foreground/70">
              <li className="flex gap-3">
                <span className="text-destructive">•</span>
                <span>Early termination fees from previous providers (these were your existing obligation)</span>
              </li>
              <li className="flex gap-3">
                <span className="text-destructive">•</span>
                <span>Technical issues with service quality (contact provider support)</span>
              </li>
              <li className="flex gap-3">
                <span className="text-destructive">•</span>
                <span>Changes in provider pricing after activation</span>
              </li>
              <li className="flex gap-3">
                <span className="text-destructive">•</span>
                <span>Your local area changes in provider availability</span>
              </li>
            </ul>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">Your Savings Guarantee</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              We stand by our recommendations. If we recommend a switch and you don't see the projected savings within the first month of billing, we will:
            </p>
            <ul className="space-y-3">
              <li className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground/70">Review the actual charges versus projections</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground/70">Identify any hidden fees or billing errors</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground/70">Help you contact the provider to resolve discrepancies</span>
              </li>
            </ul>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">How to Request Support</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              If you need to use our satisfaction guarantee, simply contact us within 30 days:
            </p>
            <div className="space-y-2 text-foreground/70">
              <p><span className="font-semibold text-foreground">Phone:</span> 1-800-CABLE-GUIDE</p>
              <p><span className="font-semibold text-foreground">Email:</span> support@cableguide.com</p>
              <p><span className="font-semibold text-foreground">Hours:</span> Monday-Friday, 9am-8pm EST</p>
            </div>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">Important Notes</h2>
            <ul className="space-y-3 text-foreground/70">
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>This guarantee applies only to recommendations made through CableGuide</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>You must contact us within 30 days to use this guarantee</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>All satisfaction claims require documentation (bills, account details)</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>This is a satisfaction guarantee, not a price-match guarantee</span>
              </li>
            </ul>
          </GlassCard>

          <GlassCard className="p-8 text-center" glow="blue">
            <h3 className="text-2xl font-bold text-foreground mb-4">We're Confident in Our Recommendations</h3>
            <p className="text-foreground/70 leading-relaxed">
              We've helped thousands of customers save money. We wouldn't be in business without the trust of our customers. Your satisfaction is our priority, and this guarantee proves it.
            </p>
          </GlassCard>
        </div>
      </section>

      <section className="py-20 bg-card/10 backdrop-blur-sm border-t border-border/20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-3xl font-bold text-foreground">Ready to Get Started?</h2>
          <p className="text-lg text-foreground/70">
            Your free consultation comes with zero risk. Let's find you better plans.
          </p>
          <button className="inline-block px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-colors">
            Schedule Free Consultation
          </button>
        </div>
      </section>
    </main>
  );
}
