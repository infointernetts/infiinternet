import { GlassCard } from '@/components/glass-card';

export const metadata = {
  title: 'Privacy Policy - CableGuide',
  description: 'Our privacy policy and how we protect your data.',
};

export default function PrivacyPage() {
  return (
    <main>
      <section className="py-20 bg-card/10 backdrop-blur-sm border-b border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-foreground mb-6">Privacy Policy</h1>
          <p className="text-lg text-foreground/70">
            Last updated: February 2024
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">1. Information We Collect</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              We collect information you provide directly to us, such as your name, phone number, email address, current ISP, current plan details, and service address. This information is used solely to provide consultation services.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">2. How We Use Your Information</h2>
            <ul className="space-y-3 text-foreground/70">
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>To provide cable and internet guidance services</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>To analyze your current plan and identify savings opportunities</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>To follow up with consultation results and recommendations</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>To communicate about your switching process</span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent">•</span>
                <span>To improve our services based on feedback</span>
              </li>
            </ul>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">3. Data Security</h2>
            <p className="text-foreground/70 leading-relaxed">
              We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. Your data is encrypted and stored securely.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">4. Third-Party Sharing</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              We do not sell your personal information. We may share your information with internet service providers only when you authorize us to proceed with a switch, and only the information necessary to complete the transaction.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="blue">
            <h2 className="text-2xl font-bold text-foreground mb-4">5. Your Rights</h2>
            <p className="text-foreground/70 leading-relaxed mb-4">
              You have the right to access, correct, or delete your personal information at any time. To exercise these rights, please contact us directly.
            </p>
          </GlassCard>

          <GlassCard className="p-8" glow="purple">
            <h2 className="text-2xl font-bold text-foreground mb-4">6. Contact Us</h2>
            <p className="text-foreground/70 leading-relaxed">
              If you have questions about this privacy policy, please contact us at privacy@cableguide.com or call 1-800-CABLE-GUIDE.
            </p>
          </GlassCard>
        </div>
      </section>
    </main>
  );
}
