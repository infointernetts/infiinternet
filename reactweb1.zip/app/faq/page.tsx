import { GlassCard } from '@/components/glass-card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

export const metadata = {
  title: 'FAQ - CableGuide',
  description: 'Frequently asked questions about cable and internet plans, switching providers, and our services.',
};

export default function FaqPage() {
  const faqs = [
    {
      category: 'General Questions',
      items: [
        {
          question: 'How much does your consultation cost?',
          answer:
            'Our initial consultation is completely free. There are no hidden charges or obligations. You get expert advice with zero financial risk.',
        },
        {
          question: 'What if I'm not satisfied with the results?',
          answer:
            'We stand behind our recommendations. If you're unhappy within 30 days, we'll help you explore other options at no additional cost.',
        },
        {
          question: 'Are you affiliated with any ISPs?',
          answer:
            'No. We are completely independent and not affiliated with any internet service provider. This ensures our recommendations are truly unbiased.',
        },
      ],
    },
    {
      category: 'Switching & Contracts',
      items: [
        {
          question: 'Will switching damage my credit?',
          answer:
            'No. Switching internet or cable providers does not affect your credit score. It's a simple service change, not a credit inquiry.',
        },
        {
          question: 'What if I'm locked in a contract?',
          answer:
            'Many contracts have buyout options or windows to switch without penalties. We'll analyze your specific situation and find the best path forward.',
        },
        {
          question: 'How long does switching usually take?',
          answer:
            'Most customers complete the entire process—from consultation to new service activation—in 7-10 business days. No downtime required.',
        },
      ],
    },
    {
      category: 'Providers & Services',
      items: [
        {
          question: 'Do you work with all providers?',
          answer:
            'We have partnerships with most major and regional providers. Even if your preferred provider isn't listed, we can still help you compare options.',
        },
        {
          question: 'Can you help if I live in a rural area?',
          answer:
            'Yes! We work with customers everywhere. Rural areas often have unique options—sometimes more than you'd expect. Call for details.',
        },
        {
          question: 'What about bundled services (TV, Internet, Phone)?',
          answer:
            'We evaluate every option, including bundles and standalone plans. Sometimes bundles save money, sometimes they don't. We'll show you the real numbers.',
        },
      ],
    },
    {
      category: 'Technical Questions',
      items: [
        {
          question: 'What speeds do I actually need?',
          answer:
            'It depends on your usage. Streaming 4K? Lots of work calls? Multiple devices? We assess your patterns and recommend appropriate speeds—not ISP maximums.',
        },
        {
          question: 'Will my internet be faster after switching?',
          answer:
            'Possibly. Faster depends on what's available in your area and what you choose. We help you select the best speed-to-price ratio for your needs.',
        },
        {
          question: 'What if I have outages with the new provider?',
          answer:
            'Service quality varies by location and provider. We share customer satisfaction data to help you choose. If issues arise, we support you through resolution.',
        },
      ],
    },
  ];

  return (
    <main>
      <section className="py-20 bg-card/10 backdrop-blur-sm border-b border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h1 className="text-5xl lg:text-6xl font-bold">
            <span className="text-foreground">Questions?—</span>
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">We Have Answers</span>
          </h1>
          <p className="text-xl text-foreground/70">
            Get answers to common questions about cable and internet plans.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {faqs.map((category, idx) => (
            <div key={idx} className="space-y-6">
              <h2 className="text-2xl font-bold text-accent">{category.category}</h2>
              <GlassCard className="p-8" glow={idx % 2 === 0 ? 'blue' : 'purple'}>
                <Accordion type="single" collapsible className="w-full space-y-2">
                  {category.items.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${idx}-${index}`} className="border-border/20">
                      <AccordionTrigger className="hover:text-accent transition-colors py-4 text-left">
                        <span className="font-semibold text-foreground">{faq.question}</span>
                      </AccordionTrigger>
                      <AccordionContent className="text-foreground/70 pb-4 leading-relaxed">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </GlassCard>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 bg-gradient-to-b from-transparent to-card/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Still Have Questions?</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <GlassCard className="p-8 text-center space-y-4" glow="blue">
              <h3 className="text-xl font-semibold text-foreground">Call Us</h3>
              <p className="text-accent text-2xl font-bold">(888) XXX-XXXX</p>
              <p className="text-foreground/70 text-sm">Mon-Fri, 8am-8pm EST</p>
            </GlassCard>

            <GlassCard className="p-8 text-center space-y-4" glow="purple">
              <h3 className="text-xl font-semibold text-foreground">Email Us</h3>
              <p className="text-accent text-lg">hello@cableguide.com</p>
              <p className="text-foreground/70 text-sm">Response within 24 hours</p>
            </GlassCard>

            <GlassCard className="p-8 text-center space-y-4" glow="blue">
              <h3 className="text-xl font-semibold text-foreground">Live Chat</h3>
              <p className="text-foreground/70 text-sm">Available on our website</p>
              <p className="text-foreground/70 text-sm">10am-6pm EST, 7 days a week</p>
            </GlassCard>
          </div>
        </div>
      </section>

      <section className="py-20 bg-card/10 backdrop-blur-sm border-t border-border/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <h2 className="text-3xl font-bold text-center mb-8">
            <span className="text-foreground">How to Use This </span>
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Guide</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <GlassCard className="p-8" glow="blue">
              <h3 className="font-semibold text-foreground text-lg mb-4">Start Here</h3>
              <ol className="space-y-3 text-foreground/70">
                <li className="flex gap-3">
                  <span className="text-accent font-bold">1.</span>
                  <span>Read through the categories above for quick answers</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-accent font-bold">2.</span>
                  <span>Click questions to expand detailed answers</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-accent font-bold">3.</span>
                  <span>Use the contact options if you need more help</span>
                </li>
              </ol>
            </GlassCard>

            <GlassCard className="p-8" glow="purple">
              <h3 className="font-semibold text-foreground text-lg mb-4">Next Steps</h3>
              <ul className="space-y-3 text-foreground/70">
                <li className="flex gap-2">
                  <span className="text-accent">→</span>
                  <span>Schedule a free consultation to discuss your specific situation</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">→</span>
                  <span>Learn more about our process on the How It Works page</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">→</span>
                  <span>Explore our full service offerings and guarantees</span>
                </li>
              </ul>
            </GlassCard>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-3xl font-bold text-foreground">Ready to Save?</h2>
          <p className="text-lg text-foreground/70">
            Get your free consultation today. No obligations, no pressure. Just expert guidance on saving money.
          </p>
          <button className="inline-block px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-colors">
            Schedule Free Consultation
          </button>
        </div>
      </section>
    </main>
  );
}
